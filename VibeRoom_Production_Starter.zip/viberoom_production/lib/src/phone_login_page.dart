import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PhoneLoginPage extends StatefulWidget {
  const PhoneLoginPage({super.key});
  @override
  State<PhoneLoginPage> createState() => _PhoneLoginPageState();
}

class _PhoneLoginPageState extends State<PhoneLoginPage> {
  final phone = TextEditingController();
  final otp = TextEditingController();
  String? verificationId;
  int? resendToken;
  bool busy = false;
  String error = '';
  bool codeSent = false;

  Future<void> requestOtp() async {
    setState(() { busy = true; error = ''; });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone.text.trim(), // Use E.164 format, e.g. +91XXXXXXXXXX
      timeout: const Duration(seconds: 60),
      forceResendingToken: resendToken,
      verificationCompleted: (credential) async {
        await _signIn(credential);
      },
      verificationFailed: (e) {
        if (mounted) setState(() { busy = false; error = e.message ?? 'OTP request failed'; });
      },
      codeSent: (id, token) {
        if (mounted) setState(() { verificationId = id; resendToken = token; codeSent = true; busy = false; });
      },
      codeAutoRetrievalTimeout: (id) {
        verificationId = id;
        if (mounted) setState(() => busy = false);
      },
    );
  }

  Future<void> verifyOtp() async {
    if (verificationId == null) return;
    setState(() { busy = true; error = ''; });
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId!, smsCode: otp.text.trim(),
      );
      await _signIn(credential);
    } on FirebaseAuthException catch (e) {
      if (mounted) setState(() { busy = false; error = e.message ?? 'Invalid OTP'; });
    }
  }

  Future<void> _signIn(PhoneAuthCredential credential) async {
    try {
      final result = await FirebaseAuth.instance.signInWithCredential(credential);
      final user = result.user!;
      final ref = FirebaseFirestore.instance.collection('users').doc(user.uid);
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final snap = await tx.get(ref);
        if (!snap.exists) {
          tx.set(ref, {
            'uid': user.uid, 'phoneNumber': user.phoneNumber,
            'displayName': 'Vibe${user.uid.substring(0, 5)}',
            'photoUrl': '', 'coins': 100, 'vipTier': 'free',
            'role': 'user', 'isBanned': false,
            'createdAt': FieldValue.serverTimestamp(),
            'language': 'hi',
          });
        }
      });
    } on FirebaseAuthException catch (e) {
      if (mounted) setState(() { busy = false; error = e.message ?? 'Sign-in failed'; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.graphic_eq, size: 72, color: Color(0xFFB89AFF)),
          const SizedBox(height: 10),
          const Text('VibeRoom', textAlign: TextAlign.center,
            style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
          const Text('Your voice. Your room. Your people.',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 32),
          TextField(controller: phone, keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Phone number (+91...)', border: OutlineInputBorder())),
          if (codeSent) ...[
            const SizedBox(height: 12),
            TextField(controller: otp, keyboardType: TextInputType.number,
              maxLength: 6, decoration: const InputDecoration(labelText: '6-digit OTP', border: OutlineInputBorder())),
          ],
          if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8),
            child: Text(error, style: const TextStyle(color: Colors.redAccent))),
          const SizedBox(height: 16),
          FilledButton(onPressed: busy ? null : (codeSent ? verifyOtp : requestOtp),
            child: Text(busy ? 'Please wait…' : codeSent ? 'Verify OTP' : 'Send OTP')),
          if (codeSent) TextButton(onPressed: busy ? null : requestOtp, child: const Text('Resend OTP')),
          const SizedBox(height: 10),
          const Text('By continuing, you agree to our Terms and Privacy Policy.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.white54)),
        ]),
      ),
    )),
  );
}
