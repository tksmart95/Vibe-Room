import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'voice_room_page.dart';
import 'wallet_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  final roomName = TextEditingController();

  Future<void> createRoom() async {
    final name = roomName.text.trim();
    if (name.isEmpty) return;
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final user = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    final room = await FirebaseFirestore.instance.collection('rooms').add({
      'name': name, 'hostId': uid, 'hostName': user.data()?['displayName'] ?? 'Host',
      'status': 'live', 'seatCapacity': 8, 'memberCount': 1,
      'speakerIds': [uid], 'language': 'hi-en', 'category': 'Chill & Talk',
      'createdAt': FieldValue.serverTimestamp(), 'isLocked': false,
    });
    roomName.clear();
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) =>
      VoiceRoomPage(roomId: room.id, roomName: name, isHost: true)));
  }

  @override
  Widget build(BuildContext context) {
    final screens = [_discover(), const WalletPage(),
      const Center(child: Text('Friends & messages module — next feature milestone')),
      const _Profile()];
    return Scaffold(
      appBar: AppBar(title: const Text('VibeRoom', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: () => FirebaseAuth.instance.signOut(),
          icon: const Icon(Icons.logout))]),
      body: screens[tab],
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true,
          builder: (_) => Padding(padding: EdgeInsets.fromLTRB(20, 20, 20,
            MediaQuery.of(context).viewInsets.bottom + 20),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('Create an 8-seat voice room', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              TextField(controller: roomName, decoration: const InputDecoration(labelText: 'Room name')),
              const SizedBox(height: 12),
              FilledButton(onPressed: () { Navigator.pop(context); createRoom(); },
                child: const Text('Create room')),
            ])),
        ),
        icon: const Icon(Icons.add), label: const Text('Create room')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.explore), label: 'Rooms'),
          NavigationDestination(icon: Icon(Icons.wallet), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.people), label: 'Friends'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ]),
    );
  }

  Widget _discover() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance.collection('rooms')
      .where('status', isEqualTo: 'live').orderBy('createdAt', descending: true).snapshots(),
    builder: (context, snapshot) {
      if (snapshot.hasError) return Center(child: Text('Room load error: ${snapshot.error}'));
      if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
      final rooms = snapshot.data!.docs;
      if (rooms.isEmpty) return const Center(child: Text('No live rooms. Create the first one!'));
      return ListView(padding: const EdgeInsets.all(16), children: [
        Text('Live voice rooms', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        ...rooms.map((doc) {
          final d = doc.data();
          return Card(color: const Color(0xFF211A35), child: ListTile(
            leading: const CircleAvatar(backgroundColor: Color(0xFF7651C9), child: Icon(Icons.mic)),
            title: Text(d['name'] ?? 'Room'),
            subtitle: Text('${d['hostName'] ?? 'Host'} · ${d['memberCount'] ?? 0}/8'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) =>
              VoiceRoomPage(roomId: doc.id, roomName: d['name'] ?? 'Room',
                isHost: d['hostId'] == FirebaseAuth.instance.currentUser?.uid))),
          ));
        }),
      ]);
    },
  );
}

class _Profile extends StatelessWidget {
  const _Profile();
  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (context, snap) {
        final d = snap.data?.data() ?? {};
        return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
          const SizedBox(height: 10), Text(d['displayName'] ?? 'VibeRoom member'),
          Text('🪙 ${d['coins'] ?? 0} coins  ·  VIP: ${d['vipTier'] ?? 'free'}'),
        ]));
      },
    );
  }
}
