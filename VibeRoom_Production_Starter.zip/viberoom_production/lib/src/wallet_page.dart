import 'package:cloud_functions/cloud_functions.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

class WalletPage extends StatefulWidget {
  const WalletPage({super.key});
  @override
  State<WalletPage> createState() => _WalletPageState();
}
class _WalletPageState extends State<WalletPage> {
  final iap = InAppPurchase.instance;
  bool available = false;
  String status = 'Wallet uses server-verified purchases only.';
  @override
  void initState() { super.initState(); _checkStore(); }
  Future<void> _checkStore() async {
    available = await iap.isAvailable();
    if (mounted) setState(() => status = available
      ? 'Store available. Configure product IDs and server receipt verification.'
      : 'In-app purchases unavailable on this device.');
  }
  Future<void> _buy(String productId) async {
    final response = await iap.queryProductDetails({productId});
    if (response.productDetails.isEmpty) {
      setState(() => status = 'Product not configured in Play Console: $productId');
      return;
    }
    await iap.buyConsumable(purchaseParam: PurchaseParam(productDetails: response.productDetails.first));
    setState(() => status = 'Purchase started. Backend receipt verification must credit coins.');
  }
  Future<void> _gift(String recipientUid, String giftId) async {
    try {
      final result = await FirebaseFunctions.instance.httpsCallable('sendGift')
        .call({'recipientUid': recipientUid, 'giftId': giftId});
      setState(() => status = 'Gift sent: ${result.data['gift']}');
    } on FirebaseFunctionsException catch (e) {
      setState(() => status = e.message ?? 'Gift failed');
    }
  }
  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (context, snap) {
        final d = snap.data?.data() ?? {};
        return ListView(padding: const EdgeInsets.all(18), children: [
          Text('My wallet', style: Theme.of(context).textTheme.headlineSmall),
          Card(color: const Color(0xFF30244F), child: Padding(padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('COIN BALANCE'), Text('${d['coins'] ?? 0} 🪙',
                style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              Text('Membership: ${d['vipTier'] ?? 'free'}'),
            ]))),
          const SizedBox(height: 12), const Text('Coin packages'),
          ListTile(title: const Text('Starter pack · 500 coins'), subtitle: const Text('Product ID: viberoom_coins_500'),
            trailing: FilledButton(onPressed: () => _buy('viberoom_coins_500'), child: const Text('Buy'))),
          ListTile(title: const Text('Popular pack · 1,200 coins'), subtitle: const Text('Product ID: viberoom_coins_1200'),
            trailing: FilledButton(onPressed: () => _buy('viberoom_coins_1200'), child: const Text('Buy'))),
          const Divider(), const Text('VIP membership'),
          const Text('VIP benefits can include profile frames, badges and room themes. Configure subscription products in Play Console.'),
          ListTile(title: const Text('VIP monthly'), subtitle: const Text('Product ID: viberoom_vip_monthly'),
            trailing: OutlinedButton(onPressed: () => _buy('viberoom_vip_monthly'), child: const Text('Subscribe'))),
          const Divider(),
          const Text('Send a gift (recipient UID required)'),
          const Text('Gift sending is callable only through the secure backend; add friend selection UI before launch.'),
          Wrap(spacing: 8, children: [
            OutlinedButton(onPressed: null, child: const Text('🌹 Rose · 10')),
            OutlinedButton(onPressed: null, child: const Text('❤️ Heart · 50')),
            OutlinedButton(onPressed: null, child: const Text('👑 Crown · 250')),
          ]),
          const SizedBox(height: 12), Text(status, style: const TextStyle(color: Colors.white60)),
        ]);
      },
    );
  }
}
