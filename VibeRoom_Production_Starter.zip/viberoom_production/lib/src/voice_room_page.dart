import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:zego_uikit_prebuilt_live_audio_room/zego_uikit_prebuilt_live_audio_room.dart';

const zegoAppId = int.fromEnvironment('ZEGO_APP_ID', defaultValue: 0);
const zegoAppSign = String.fromEnvironment('ZEGO_DEV_APP_SIGN');

class VoiceRoomPage extends StatelessWidget {
  final String roomId, roomName;
  final bool isHost;
  const VoiceRoomPage({super.key, required this.roomId, required this.roomName, required this.isHost});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    if (zegoAppId == 0 || zegoAppSign.isEmpty) {
      return Scaffold(appBar: AppBar(title: Text(roomName)),
        body: const Center(child: Padding(padding: EdgeInsets.all(24),
          child: Text('Voice SDK configuration required. Configure ZEGO for local development; production must use short-lived server-issued tokens.',
            textAlign: TextAlign.center))));
    }
    return Scaffold(body: SafeArea(child: ZegoUIKitPrebuiltLiveAudioRoom(
      appID: zegoAppId,
      appSign: zegoAppSign, // Development smoke test only; replace with token flow before release.
      userID: user.uid,
      userName: user.displayName ?? 'VibeRoom member',
      roomID: roomId,
      config: isHost ? ZegoUIKitPrebuiltLiveAudioRoomConfig.host()
        : ZegoUIKitPrebuiltLiveAudioRoomConfig.audience(),
    )));
  }
}
