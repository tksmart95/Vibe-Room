import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'firebase_options.dart';
import 'src/auth_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // Activate Play Integrity for Android production. Use debug provider only in debug builds.
  await FirebaseAppCheck.instance.activate(
    androidProvider: const bool.fromEnvironment('dart.vm.product')
        ? AndroidProvider.playIntegrity
        : AndroidProvider.debug,
  );
  runApp(const VibeRoomApp());
}

class VibeRoomApp extends StatelessWidget {
  const VibeRoomApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VibeRoom',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF100D1C),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark),
      textTheme: GoogleFonts.poppinsTextTheme(ThemeData.dark().textTheme),
    ),
    home: const AuthGate(),
  );
}
