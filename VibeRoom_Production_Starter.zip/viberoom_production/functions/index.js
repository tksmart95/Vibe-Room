const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
initializeApp();
const db = getFirestore();

const giftCatalog = {
  rose: { label: 'Rose', coins: 10 },
  heart: { label: 'Heart', coins: 50 },
  crown: { label: 'Crown', coins: 250 },
};

exports.sendGift = onCall(async (req) => {
  if (!req.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const { recipientUid, giftId, roomId } = req.data || {};
  if (typeof recipientUid !== 'string' || !giftCatalog[giftId])
    throw new HttpsError('invalid-argument', 'Invalid recipient or gift.');
  if (recipientUid === req.auth.uid) throw new HttpsError('failed-precondition', 'Cannot gift yourself.');
  const gift = giftCatalog[giftId];
  const senderRef = db.collection('users').doc(req.auth.uid);
  const recipientRef = db.collection('users').doc(recipientUid);
  const transactionRef = db.collection('transactions').doc();
  await db.runTransaction(async tx => {
    const sender = await tx.get(senderRef);
    const recipient = await tx.get(recipientRef);
    if (!sender.exists || !recipient.exists) throw new HttpsError('not-found', 'User not found.');
    if (sender.data().isBanned) throw new HttpsError('permission-denied', 'Account restricted.');
    const balance = Number(sender.data().coins || 0);
    if (balance < gift.coins) throw new HttpsError('failed-precondition', 'Insufficient coins.');
    tx.update(senderRef, { coins: balance - gift.coins });
    tx.update(recipientRef, { receivedGiftCount: FieldValue.increment(1) });
    tx.set(transactionRef, {
      fromUid: req.auth.uid, toUid: recipientUid, giftId,
      coins: gift.coins, roomId: roomId || null,
      createdAt: FieldValue.serverTimestamp(), type: 'gift'
    });
  });
  return { ok: true, gift: gift.label, coins: gift.coins };
});

exports.reportUser = onCall(async req => {
  if (!req.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const { targetUid, reason, roomId } = req.data || {};
  if (typeof targetUid !== 'string' || typeof reason !== 'string' || reason.trim().length < 3 || reason.length > 500)
    throw new HttpsError('invalid-argument', 'Provide a short report reason.');
  await db.collection('reports').add({
    reporterUid: req.auth.uid, targetUid, reason: reason.trim(),
    roomId: roomId || null, status: 'open', createdAt: FieldValue.serverTimestamp()
  });
  return { ok: true };
});

// Production TODO: implement and test:
// - ZEGO short-lived token callable using ZEGO server-side token generator + Secret Manager.
// - Google Play Developer API purchase-token verification before granting coins/VIP.
// - Idempotency keys for purchase events; never credit based on client callback.
// - Admin-only callable moderation actions, audit logs, and role assignment.
