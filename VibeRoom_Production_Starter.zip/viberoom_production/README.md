# VibeRoom production-oriented Android starter

Configuration selected:
- Phone number + OTP login
- 8-seat room documents
- Free starter coins + planned VIP + paid gifts
- Hindi + English-ready data model

## What is implemented in this source package
- Firebase Phone Auth screen (E.164 phone number, OTP verification, resend)
- User profile creation with 100 starter coins and free VIP tier
- Live room discovery and 8-seat room creation metadata
- ZEGO Live Audio Room Kit integration point
- Wallet screen with Google Play Billing product placeholders
- Server-side transactional gift debit function
- User reporting function
- Firestore rules that deny client-side writes to wallet transactions

## What is not production-complete yet
This is a development foundation, not a finished production app or verified APK. The following must be completed and tested before release:
1. ZEGO server token function + Secret Manager integration; replace the development AppSign path with short-lived tokens.
2. Server-side Google Play purchase token verification using Google Play Developer API, idempotent event processing, refund/revoke handling, and VIP entitlement expiry.
3. Friend search/requests/blocks, DMs, room chat, speaker seat request/approval, host mute/kick/lock/end-room controls.
4. Full gift animation/catalog UI and recipient selection.
5. Admin dashboard, role provisioning from trusted server, report queue, bans and audit trail.
6. Proper localization ARB files and Hindi/English UI strings.
7. Privacy policy, terms, community standards, account deletion, age/safety measures and moderation operations.
8. Physical-device testing, load testing, billing sandbox tests, App Check enforcement and monitoring.

## Setup
Install Flutter, Android Studio, Firebase CLI, Node 20 and FlutterFire CLI.

```bash
flutter create . --platforms=android
flutter pub get
dart pub global activate flutterfire_cli
firebase login
flutterfire configure
```

Enable Firebase Phone Authentication in Firebase Console. Add the Android SHA-1 and SHA-256 fingerprints for debug and release signing. Configure SMS region policy, quotas and test phone numbers. `flutterfire configure` creates `lib/firebase_options.dart`, intentionally excluded because it is project-specific.

Create Firestore and deploy rules/functions:

```bash
cd functions && npm install && cd ..
firebase use YOUR_FIREBASE_PROJECT_ID
firebase deploy --only firestore:rules,functions
```

Set up ZEGO Live Audio Room Kit. The current included `appSign` path is for local development only. Do not distribute an APK containing a ZEGO ServerSecret/AppSign. Generate short-lived tokens on a trusted server and validate Firebase identity, room ID, user role and expiry before issuing.

## Google Play Billing
Create products in Play Console matching the placeholders:
- `viberoom_coins_500` (consumable)
- `viberoom_coins_1200` (consumable)
- `viberoom_vip_monthly` (subscription)

The Flutter screen only starts a billing purchase flow. It intentionally does not credit coins or VIP from the client callback. Implement backend verification with the Google Play Developer API, verify package name/product ID/purchase token/state, acknowledge purchases, enforce idempotency, and process RTDN notifications before crediting entitlements. Follow current Google Play Billing policies for digital goods.

## Android build
```bash
flutter build apk --debug
flutter build appbundle --release
```
Release AAB: `build/app/outputs/bundle/release/app-release.aab`.
Use Play App Signing, protect upload key, never commit secrets, and test internal track before production.

## Security and operations
- Keep coin balance, VIP entitlements, roles and moderation actions server-authoritative.
- Use App Check, rate limits, audit logs and abuse monitoring.
- Never trust client-supplied gift prices or room capacity.
- Give users report/block controls and publish clear privacy/retention policies.
- Avoid recording voice unless there is a documented, lawful need and clear consent.
